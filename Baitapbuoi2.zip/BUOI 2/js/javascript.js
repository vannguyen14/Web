var el = document.querySelector(".box");
el.addEventListener("click", clickedBox, false);

function clickedBox(evt) {
	el.classList.remove("box");
	el.classList.toggle("bottomleft");
	console.log("clicked on box.");
}
