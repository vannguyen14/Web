$(document).ready(function(){
    $("#next").click(function(){
        var user = $("#user").val();
        var gmail = $("#gmail").val()
        var password = $("#password").val();
        if("" == user){ 
            $("#warning").css("display","block");
        }else{
            $("#warning").css("display","none");
        }
        if("" == password){ 
            $("#warning").css("display","block");
        }else{
            $("#warning").css("display","none");
        }
    })
});