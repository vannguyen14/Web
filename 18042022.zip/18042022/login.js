$(document).ready(function(){
    $("#btnlogin").click(function(){
        var user = $("#user").val();
        var password = $("#password").val();
        if("" == user){ 
            $("#warning").css("display","block");
        }else{
            $("#warning").css("display","none");
        }
        if("" == password){ 
            $("#warning").css("display","block");
        }else{
            $("#warning").css("display","none");
        }
    })
});